package ui.gui;

// Enumeration used to keep track of the main interfaces
public enum GuiType {

    CREATEACCOUNT,
    ACCESSACCOUNT,
    ACCOUNTINTERFACE,
    SAVEANDLOADINTERFACE

}
